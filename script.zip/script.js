document.addEventListener("DOMContentLoaded", () => {
    console.log("Portfolio site loaded!");
});
